"use client";

import { useEffect, useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import { LuChevronLeft, LuShieldCheck, LuClock } from "react-icons/lu";
import { adminService, PendingLicenseDoctor } from "@/services/adminService";
import LicensePendingList from "@/components/admin/licenses/LicensePendingList";

export default function AdminLicensesPage() {
  const router = useRouter();
  const [doctors, setDoctors]   = useState<PendingLicenseDoctor[]>([]);
  const [loading, setLoading]   = useState(true);
  const [error, setError]       = useState("");

  const fetchDoctors = useCallback(async () => {
    try {
      setLoading(true);
      setError("");
      const res = await adminService.getPendingLicenseDoctors();
      setDoctors(res.data ?? []);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Failed to load data.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchDoctors();
  }, [fetchDoctors]);

  const handleApprove = async (id: string) => {
    await adminService.approveDoctorLicense(id);
    setDoctors((prev) => prev.filter((d) => d._id !== id));
    // notify sidebar badge
    window.dispatchEvent(new Event("pending-licenses-changed"));
  };

  const handleReject = async (id: string, reason: string) => {
    await adminService.rejectDoctorLicense(id, reason);
    setDoctors((prev) => prev.filter((d) => d._id !== id));
    window.dispatchEvent(new Event("pending-licenses-changed"));
  };

  return (
    <div className="flex flex-col flex-1 min-h-screen bg-[hsl(var(--color-bg-soft))]">
      {/* ── Page header ──────────────────────────────────────────────────────── */}
      <header className="bg-[hsl(var(--color-bg-surface))] border-b border-[hsl(var(--color-border))] px-6 py-4">
        <div className="flex items-center gap-3">
          <button
            onClick={() => router.push("/admin")}
            className="w-[33px] h-[33px] rounded-[9px] border border-[hsl(var(--color-border))] bg-[hsl(var(--color-bg-surface))] flex items-center justify-center text-[hsl(var(--color-text-muted))] hover:bg-[hsl(var(--color-bg-soft))] hover:text-[hsl(var(--color-text))] transition-all cursor-pointer"
          >
            <LuChevronLeft className="text-[15px]" />
          </button>
          <div>
            <h1 className="text-[16px] font-black text-[hsl(var(--color-text))]">
              License Updates
            </h1>
            <p className="text-[11px] font-semibold text-[hsl(var(--color-text-muted))] mt-0.5">
              Review new license submissions from approved doctors
            </p>
          </div>
        </div>
      </header>

      <main className="flex-1 p-6">
        {/* ── Stats strip ────────────────────────────────────────────────────── */}
        <div className="grid grid-cols-2 gap-4 mb-6 max-w-sm">
          <div className="bg-[hsl(var(--color-bg-surface))] border border-[hsl(var(--color-border))] rounded-2xl px-4 py-3 flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-[hsl(var(--color-warning-bg))] flex items-center justify-center shrink-0">
              <LuClock className="w-4 h-4 text-[hsl(var(--color-warning))]" />
            </div>
            <div>
              <p className="text-[11px] font-semibold text-[hsl(var(--color-text-muted))]">Pending</p>
              <p className="text-[18px] font-black text-[hsl(var(--color-text))]">{loading ? "—" : doctors.length}</p>
            </div>
          </div>

          <div className="bg-[hsl(var(--color-bg-surface))] border border-[hsl(var(--color-border))] rounded-2xl px-4 py-3 flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-[hsl(var(--color-success-bg))] flex items-center justify-center shrink-0">
              <LuShieldCheck className="w-4 h-4 text-[hsl(var(--color-success))]" />
            </div>
            <div>
              <p className="text-[11px] font-semibold text-[hsl(var(--color-text-muted))]">Reviewed</p>
              <p className="text-[18px] font-black text-[hsl(var(--color-text))]">—</p>
            </div>
          </div>
        </div>

        {/* ── Error ──────────────────────────────────────────────────────────── */}
        {error && (
          <div className="mb-4 px-4 py-3 rounded-xl bg-[hsl(var(--color-danger-bg))] text-[hsl(var(--color-danger))] text-[13px] font-medium">
            {error}
            <button onClick={fetchDoctors} className="ml-2 underline font-bold text-[12px]">
              Retry
            </button>
          </div>
        )}

        {/* ── List ───────────────────────────────────────────────────────────── */}
        <div className="bg-[hsl(var(--color-bg-surface))] border border-[hsl(var(--color-border))] rounded-2xl p-4 shadow-sm overflow-x-auto">
          <LicensePendingList
            doctors={doctors}
            loading={loading}
            onApprove={handleApprove}
            onReject={handleReject}
          />
        </div>
      </main>
    </div>
  );
}
