"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { LuBuilding2, LuSettings2, LuPencil } from "react-icons/lu";

import { useAuth } from "@/context/AuthContext";
import AppointmentToast from "@/components/appointments/AppointmentToast";
import SectionToggle from "@/components/appointments/SectionToggle";
// ── CHANGED: بنستخدم الـ shared components بدل ما نعيد كتابة الكود ──────────
import ScheduleSetup from "@/components/appointments/ScheduleSetup";
import GenerateSlotsCard from "@/components/appointments/GenerateSlotsCard";
import { getMyClinics, Clinic } from "@/services/clinicService";

export default function DoctorSchedulePage() {
  const { user } = useAuth();
  const router = useRouter();
  const doctorId = (user as any)?._id ?? user?.id ?? "";

  const [toast, setToast] = useState<{ msg: string; variant: "success" | "error" } | null>(null);
  const handleToast = (msg: string, variant: "success" | "error") => setToast({ msg, variant });

  // ── CHANGED: state للعيادات ───────────────────────────────────────────────
  const [clinics, setClinics] = useState<Clinic[]>([]);
  const [loadingClinics, setLoadingClinics] = useState(true);
  const [selectedClinicId, setSelectedClinicId] = useState<string | null>(null);
  const [hasSelectedDays, setHasSelectedDays] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const data = await getMyClinics();
        setClinics(data);
        if (data.length > 0) setSelectedClinicId(data[0]._id);
      } catch (err: any) {
        handleToast(err.message || "Failed to load clinics", "error");
      } finally {
        setLoadingClinics(false);
      }
    })();
  }, []);

  const selectedClinic = clinics.find((c) => c._id === selectedClinicId);

  return (
    <div className="flex flex-col flex-1 min-h-screen">
      {/* ── Header — نفس بالظبط زي باقي الصفحات ── */}
      <header className="bg-[hsl(var(--color-bg-surface))] border-b border-[hsl(var(--color-border))] px-4 md:px-6 py-4 flex items-center justify-between flex-wrap gap-4 shadow-[0_1px_0_hsl(var(--color-border))]">
        <div className="flex items-center gap-4">
          <div className="hidden md:flex w-12 h-12 rounded-[14px] bg-gradient-to-br from-[hsl(var(--color-primary)/0.15)] to-[hsl(var(--color-primary)/0.05)] border border-[hsl(var(--color-primary)/0.1)] text-primary items-center justify-center text-[20px] shrink-0">
            <LuSettings2 />
          </div>
          <div>
            <h1 className="text-[18px] md:text-[22px] font-black text-[hsl(var(--color-text))] tracking-tight pl-11 md:pl-0">
              My Schedule
            </h1>
            <p className="text-[12px] font-bold text-[hsl(var(--color-text-muted))] mt-0.5 pl-11 md:pl-0">
              Set your weekly hours and generate bookable slots
            </p>
          </div>
        </div>
        <SectionToggle />
      </header>

      <main className="flex-1 p-4 md:p-6 overflow-auto flex justify-center">
        <div className="w-full max-w-6xl space-y-5">

          {/* ── CHANGED: Clinic selector ─────────────────────────────────── */}
          {loadingClinics ? (
            <div className="flex gap-2">
              {[1, 2].map((i) => (
                <div key={i} className="h-10 w-28 rounded-xl bg-[hsl(var(--color-border-soft))] animate-pulse" />
              ))}
            </div>
          ) : clinics.length === 0 ? (
            // لو مفيش عيادات — نفس empty state pattern بتاع الصفحات التانية
            <div className="bg-[hsl(var(--color-bg-surface))] border border-dashed border-[hsl(var(--color-border))] rounded-2xl p-8 text-center">
              <div className="w-14 h-14 rounded-2xl bg-[hsl(var(--color-bg-soft))] border border-[hsl(var(--color-border))] flex items-center justify-center mx-auto mb-3">
                <LuBuilding2 className="text-[24px] text-[hsl(var(--color-text-muted))]" />
              </div>
              <p className="text-[15px] font-black text-[hsl(var(--color-text))]">No clinics yet</p>
              <p className="text-[12px] font-semibold text-[hsl(var(--color-text-muted))] mt-1 mb-4">
                Add a clinic first to manage its schedule
              </p>
              <button
                onClick={() => router.push("/doctor/clinics")}
                className="text-[12px] font-bold px-4 py-2.5 rounded-xl bg-[hsl(var(--color-primary))] text-[hsl(var(--color-text-inverse))] hover:opacity-90 transition-opacity"
              >
                Go to My Clinics
              </button>
            </div>
          ) : (
            // Clinic tabs — نفس style بتاع الصفحات التانية
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[11px] font-bold uppercase tracking-wider text-[hsl(var(--color-text-muted))]">
                Clinic:
              </span>
              {clinics.map((c) => (
                <button
                  key={c._id}
                  onClick={() => setSelectedClinicId(c._id)}
                  className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-[12px] font-bold border transition-all cursor-pointer ${
                    selectedClinicId === c._id
                      ? "bg-[hsl(var(--color-primary))] text-[hsl(var(--color-text-inverse))] border-[hsl(var(--color-primary))] shadow-[0_2px_8px_hsl(var(--color-primary)/0.3)]"
                      : "border-[hsl(var(--color-border))] text-[hsl(var(--color-text-muted))] hover:border-[hsl(var(--color-primary))] hover:text-[hsl(var(--color-primary))]"
                  }`}
                >
                  <LuBuilding2 className="text-[13px]" />
                  {c.name}
                </button>
              ))}
              {/* زرار Edit يروح على صفحة الـ clinic */}
              {selectedClinicId && (
                <button
                  onClick={() => router.push(`/doctor/clinics/${selectedClinicId}`)}
                  className="flex items-center gap-1 text-[11px] font-bold text-[hsl(var(--color-text-muted))] hover:text-[hsl(var(--color-primary))] transition-colors cursor-pointer ml-auto"
                >
                  <LuPencil className="text-[11px]" /> Edit clinic
                </button>
              )}
            </div>
          )}

          {/* ── CHANGED: بنستخدم الـ shared components مع الـ clinicId ───── */}
          {selectedClinicId && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* LEFT — ScheduleSetup shared component */}
              <ScheduleSetup
                clinicId={selectedClinicId}
                clinicName={selectedClinic?.name}
                onToast={handleToast}
                onSelectedDaysChange={setHasSelectedDays}
              />

              {/* RIGHT — GenerateSlotsCard shared component */}
              <GenerateSlotsCard
                clinicId={selectedClinicId}
                doctorId={doctorId}
                hasSelectedDays={hasSelectedDays}
                onToast={handleToast}
              />
            </div>
          )}
        </div>
      </main>

      {toast && (
        <AppointmentToast
          message={toast.msg}
          variant={toast.variant}
          onClose={() => setToast(null)}
        />
      )}
    </div>
  );
}
