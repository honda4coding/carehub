"use client";
import { useState } from "react";
import Link from "next/link";
import { Formik, Form, Field, ErrorMessage, FormikHelpers, FieldProps } from "formik";
import { useAuth } from "@/context/AuthContext";
import { AuthCard } from "@/components/auth/AuthCard";
import { Input } from "@/components/ui/Input";
import { Label } from "@/components/ui/Label";
import { Button } from "@/components/ui/Button";
import {
  HiOutlineMail, HiOutlineLockClosed, HiOutlineEye,
  HiOutlineEyeOff, HiShieldCheck,
} from "react-icons/hi";
import { HiOutlineArrowRight } from "react-icons/hi2";
import { ImSpinner2 } from "react-icons/im";
import {
  loginSchema,
  loginInitialValues,
  type LoginValues,
} from "../schemas/loginSchema";

const BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:3000";

export const LoginForm = () => {
  const { login } = useAuth();
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = async (
    values: LoginValues,
    { setSubmitting, setStatus }: FormikHelpers<LoginValues>,
  ) => {
    try {
      // 1. signin
      const response = await fetch(`${BASE_URL}/users/signin`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: values.email, password: values.password }),
      });

      const data = await response.json();

      if (!response.ok) {
        setStatus(data.message || "Invalid credentials. Please try again.");
        return;
      }

      const actualRole = data.data.role?.toLowerCase();

      if (!actualRole) {
        setStatus("Unable to determine account role. Please contact support.");
        return;
      }

      login(data.data.access_token, actualRole, {
        id: data.data.id,
        email: values.email,
        name: data.data.fullName || data.data.name || values.email,
      });

    } catch (error) {
      setStatus("Something went wrong. Please check your connection.");
      console.error("Login Error:", error);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="w-full">
      <AuthCard>
        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold" style={{ color: "hsl(var(--color-text))" }}>
            Welcome Back
          </h2>
          <p
            className="text-sm mt-1"
            style={{ color: "hsl(var(--color-text-muted))" }}
          >
            Sign in to your account
          </p>
        </div>

        <Formik
          initialValues={loginInitialValues}
          validationSchema={loginSchema}
          onSubmit={handleSubmit}
        >
          {({ errors, touched, isSubmitting, status }) => (
            <Form className="space-y-5">
              {status && (
                <div className="bg-danger-light border border-red-200 text-danger text-sm font-medium px-4 py-3 rounded-2xl text-center">
                  {status}
                </div>
              )}

              {/* Email */}
              <div>
                <Label>Email</Label>
                <Field name="email">
                  {({ field, meta }: FieldProps) => (
                    <Input
                      {...field}
                      type="email"
                      placeholder="name@example.com"
                      leftIcon={<HiOutlineMail className="w-5 h-5" />}
                      error={!!(meta.touched && meta.error)}
                    />
                  )}
                </Field>
                <ErrorMessage name="email" component="p" className="text-[hsl(var(--color-danger))] text-xs pl-2 font-bold mt-1" />
              </div>

              {/* Password */}
              <div>
                <Label>Password</Label>
                <Field name="password">
                  {({ field, meta }: FieldProps) => (
                    <Input
                      {...field}
                      type={showPassword ? "text" : "password"}
                      placeholder="••••••••"
                      leftIcon={<HiOutlineLockClosed className="w-5 h-5" />}
                      rightIcon={
                        <button type="button" onClick={() => setShowPassword(!showPassword)} className="hover:text-[hsl(var(--color-text))] transition-colors">
                          {showPassword ? <HiOutlineEyeOff className="w-5 h-5" /> : <HiOutlineEye className="w-5 h-5" />}
                        </button>
                      }
                      error={!!(meta.touched && meta.error)}
                    />
                  )}
                </Field>
                <ErrorMessage name="password" component="p" className="text-[hsl(var(--color-danger))] text-xs pl-2 font-bold mt-1" />
              </div>

              {/* Remember + Forgot */}
              <div className="flex items-center justify-between px-2 pt-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    className="w-5 h-5 rounded-md border-slate-300"
                    style={{ accentColor: "hsl(var(--color-primary))" }}
                  />
                  <span
                    className="text-xs font-medium"
                    style={{ color: "hsl(var(--color-text-muted))" }}
                  >
                    Stay Signed In
                  </span>
                </label>
                <div className="flex items-center gap-4">
                  <Link href="/forgot-password" className="text-xs font-bold transition-colors" style={{ color: "hsl(var(--color-primary-strong))" }}>Forgot Access?</Link>
                  <Link href="/reset-password" className="text-xs font-bold transition-colors" style={{ color: "hsl(var(--color-primary-strong))" }}>Reset Password</Link>
                </div>
              </div>

              {/* Submit */}
              <div className="pt-4">
                <Button
                  type="submit"
                  variant="gradient"
                  className="w-full"
                  isLoading={isSubmitting}
                  icon={HiOutlineArrowRight}
                  iconPosition="right"
                >
                  Enter Sanctuary
                </Button>
              </div>
            </Form>
          )}
        </Formik>

        <div className="mt-10 pt-8 border-t border-[hsl(var(--color-border))] text-center space-y-4">
          <p className="text-sm text-[hsl(var(--color-text-muted))]">
            New to Carehub?{" "}
            <Link href="/register" className="font-bold hover:underline underline-offset-4 transition-all text-[hsl(var(--color-primary))]">
              Request Enrollment
            </Link>
          </p>

          <p className="text-sm text-[hsl(var(--color-text-muted))]">
            Received an OTP from admin?{" "}
            <Link
              href="/verify-otp?type=confirm"
              className="font-bold hover:underline underline-offset-4 transition-all text-[hsl(var(--color-primary))]"
            >
              Verify here
            </Link>
          </p>
        </div>
      </AuthCard>

      {/* Security Tag */}
      <div className="mt-6 flex items-center justify-center gap-2 opacity-60">
        <HiShieldCheck className="w-4 h-4" style={{ color: "hsl(var(--color-text-muted))" }} />
        <span className="text-[10px] uppercase font-bold tracking-[0.2em]" style={{ color: "hsl(var(--color-text-muted))" }}>
          HIPAA COMPLIANT ENVIRONMENT
        </span>
      </div>
    </div>
  );
};
